import React from 'react'

export default function BooksList({ books, onEdit, onDelete }) {
  return (
    <div className="books-list">
      <table className="books-table">
        <thead>
          <tr>
            <th>Title</th>
            <th>Author</th>
            <th>ISBN</th>
            <th>Year</th>
            <th>Genre</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {books.map(book => (
            <tr key={book.id}>
              <td>
                <div className="book-title">
                  <i className="fas fa-book"></i>
                  {book.title}
                </div>
              </td>
              <td>
                <div className="book-author">
                  <i className="fas fa-user"></i>
                  {book.author}
                </div>
              </td>
              <td>
                <code className="isbn">{book.isbn}</code>
              </td>
              <td>
                <span className="year-badge">{book.published_year}</span>
              </td>
              <td>
                <span className="genre-tag">{book.genre}</span>
              </td>
              <td className="actions-cell">
                <button 
                  className="btn secondary" 
                  onClick={() => onEdit(book)}
                >
                  <i className="fas fa-edit"></i>
                </button>
                <button 
                  className="btn danger" 
                  onClick={() => onDelete(book.id)}
                >
                  <i className="fas fa-trash"></i>
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}