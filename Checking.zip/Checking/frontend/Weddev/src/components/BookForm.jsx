import React, { useState, useEffect } from 'react'

export default function BookForm({ onAdd, onUpdate, editing }) {
  const [book, setBook] = useState({
    title: '',
    author: '',
    isbn: '',
    published_year: '',
    genre: ''
  })

  useEffect(() => {
    if (editing) {
      setBook(editing)
    } else {
      setBook({
        title: '',
        author: '',
        isbn: '',
        published_year: '',
        genre: ''
      })
    }
  }, [editing])

  function handleChange(e) {
    setBook({
      ...book,
      [e.target.name]: e.target.value
    })
  }

  function handleSubmit(e) {
    e.preventDefault()
    if (editing) {
      onUpdate(editing.id, book)
    } else {
      onAdd(book)
      setBook({
        title: '',
        author: '',
        isbn: '',
        published_year: '',
        genre: ''
      })
    }
  }

  function handleCancel() {
    setBook({
      title: '',
      author: '',
      isbn: '',
      published_year: '',
      genre: ''
    })
  }

  return (
    <form className="book-form" onSubmit={handleSubmit}>
      <div className="form-group">
        <label htmlFor="title">
          <i className="fas fa-heading"></i>
          Title
        </label>
        <input
          type="text"
          id="title"
          name="title"
          value={book.title}
          onChange={handleChange}
          placeholder="Enter book title"
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="author">
          <i className="fas fa-user-pen"></i>
          Author
        </label>
        <input
          type="text"
          id="author"
          name="author"
          value={book.author}
          onChange={handleChange}
          placeholder="Enter author name"
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="isbn">
          <i className="fas fa-barcode"></i>
          ISBN
        </label>
        <input
          type="text"
          id="isbn"
          name="isbn"
          value={book.isbn}
          onChange={handleChange}
          placeholder="Enter ISBN"
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="published_year">
          <i className="fas fa-calendar"></i>
          Published Year
        </label>
        <input
          type="number"
          id="published_year"
          name="published_year"
          value={book.published_year}
          onChange={handleChange}
          placeholder="Enter published year"
          min="1000"
          max={new Date().getFullYear()}
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="genre">
          <i className="fas fa-tag"></i>
          Genre
        </label>
        <input
          type="text"
          id="genre"
          name="genre"
          value={book.genre}

          onChange={handleChange}
          placeholder="Enter genre"
          required
        />
      </div>

      <div className="form-actions">
        <button type="submit" className="btn primary">
          <i className={`fas ${editing ? 'fa-save' : 'fa-plus'}`}></i>
          {editing ? 'Update ' : 'Add '}
        </button>
        {editing && (
          <button type="button" className="btn secondary" onClick={handleCancel}>
            <i className="fas fa-times"></i>
            Cancel Edit
          </button>
        )}
      </div>
    </form>
  )
}
