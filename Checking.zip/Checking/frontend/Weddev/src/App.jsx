import React, { useEffect, useState } from 'react'
import './App.css'
import BooksList from './components/BooksList'
import BookForm from './components/BookForm'

const API = 'http://localhost:5000'

export default function App() {
  const [books, setBooks] = useState([])
  const [editing, setEditing] = useState(null)
  const [loading, setLoading] = useState(true)
  const [notification, setNotification] = useState({ show: false, message: '', type: '' })

  async function fetchBooks() {
    setLoading(true)
    try {
      const res = await fetch(`${API}/books`)
      const data = await res.json()
      setBooks(data)
    } catch (error) {
      showNotification('Failed to fetch books', 'error')
    } finally {
      setLoading(false)
    }
  }

  function showNotification(message, type = 'success') {
    setNotification({ show: true, message, type })
    setTimeout(() => setNotification({ show: false, message: '', type: '' }), 3000)
  }

  useEffect(() => {
    fetchBooks()
  }, [])

  async function handleAdd(book) {
    try {
      await fetch(`${API}/books`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(book)
      })
      showNotification('Book added successfully!')
      fetchBooks()
    } catch (error) {
      showNotification('Failed to add book', 'error')
    }
  }

  async function handleUpdate(id, book) {
    try {
      await fetch(`${API}/books/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(book)
      })
      showNotification('Book updated successfully!')
      setEditing(null)
      fetchBooks()
    } catch (error) {
      showNotification('Failed to update book', 'error')
    }
  }

  async function handleDelete(id) {
    if (!window.confirm('Are you sure you want to delete this book?')) return
    
    try {
      await fetch(`${API}/books/${id}`, { method: 'DELETE' })
      showNotification('Book deleted successfully!')
      fetchBooks()
    } catch (error) {
      showNotification('Failed to delete book', 'error')
    }
  }

  return (
    <div id="app-root">
      {notification.show && (
        <div className={`notification ${notification.type}`}>
          {notification.message}
        </div>
      )}
      
      <header className="app-header">
        <div className="header-content">
          <h1>
            <i className="fas fa-book-reader"></i>
            Library Management System
          </h1>
          <p className="subtitle">Manage your book collection with ease</p>
        </div>
        <div className="stats">
          <div className="stat-card">
            <i className="fas fa-book"></i>
            <span>{books.length} Books</span>
          </div>
        </div>
      </header>
      
      <main className="app-main">
        <section className="left-section">
          <div className="section-card">
            <h2>
              <i className="fas fa-edit"></i>
              {editing ? 'Edit Book' : 'Add New Book'}
            </h2>
            <BookForm onAdd={handleAdd} onUpdate={handleUpdate} editing={editing} />
          </div>
          
        
        </section>
        
        <section className="right-section">
          <div className="section-card">
            <div className="section-header">
              <h2>
                <i className="fas fa-list"></i>
                Book Collection
              </h2>
              <button className="btn refresh-btn" onClick={fetchBooks} disabled={loading}>
                <i className="fas fa-sync-alt"></i>
                Refresh
              </button>
            </div>
            
            {loading ? (
              <div className="loading">
                <i className="fas fa-spinner fa-spin"></i>
                <p>Loading books...</p>
              </div>
            ) : books.length === 0 ? (
              <div className="empty-state">
                <i className="fas fa-book-open"></i>
                <h3>No books yet</h3>
                <p>Start by adding your first book!</p>
              </div>
            ) : (
              <BooksList books={books} onEdit={setEditing} onDelete={handleDelete} />
            )}
          </div>
        </section>
      </main>
      
      <footer className="app-footer">
        <p>
          <i className="fas fa-code"></i>
          Built with React 
        </p>
        <p className="muted">© {new Date().getFullYear()} Library Management System</p>
      </footer>
    </div>
  )
}