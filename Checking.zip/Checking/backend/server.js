﻿import express from "express";
import fs from "fs/promises";
import path from "path";
import { fileURLToPath } from 'url';
import cors from 'cors';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

const DATA_FILE = path.join(__dirname, 'books.json');

async function readBooks() {
  try {
    const txt = await fs.readFile(DATA_FILE, 'utf-8');
    return JSON.parse(txt || '[]');
  } catch (err) {
    if (err.code === 'ENOENT') {
      await fs.writeFile(DATA_FILE, '[]', 'utf-8');
      return [];
    }
    throw err;
  }
}

async function writeBooks(books) {
  await fs.writeFile(DATA_FILE, JSON.stringify(books, null, 2), 'utf-8');
}

app.get('/', (req, res) => {
  res.send('Backend running successfully');
});

// Get all books
app.get('/books', async (req, res) => {
  const books = await readBooks();
  res.json(books);
});

// Get book by id
app.get('/books/:id', async (req, res) => {
  const books = await readBooks();
  const book = books.find(b => String(b.id) === String(req.params.id));
  if (!book) return res.status(404).json({ error: 'Book not found' });
  res.json(book);
});

// Add book
app.post('/books', async (req, res) => {
  const { title, author, year, isbn } = req.body;
  if (!title || !author) return res.status(400).json({ error: 'Missing title or author' });
  const books = await readBooks();
  const newBook = {
    id: Date.now().toString(),
    title,
    author,
    year: year || '',
    isbn: isbn || ''
  };
  books.push(newBook);
  await writeBooks(books);
  res.status(201).json(newBook);
});

// Update book
app.put('/books/:id', async (req, res) => {
  const books = await readBooks();
  const idx = books.findIndex(b => String(b.id) === String(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Book not found' });
  const updated = { ...books[idx], ...req.body };
  books[idx] = updated;
  await writeBooks(books);
  res.json(updated);
});

// Delete book
app.delete('/books/:id', async (req, res) => {
  let books = await readBooks();
  const initialLen = books.length;
  books = books.filter(b => String(b.id) !== String(req.params.id));
  if (books.length === initialLen) return res.status(404).json({ error: 'Book not found' });
  await writeBooks(books);
  res.json({ success: true });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
